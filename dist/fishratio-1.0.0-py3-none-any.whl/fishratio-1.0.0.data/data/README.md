### Fish Ratio
Calculate the ratio and logarithmic value of species contained in several genus of a family to all species in this family

### Author
[Author: benben-miao](https://github.com/benben-miao)
[Email: benben.miao@outlook.com](benben.miao@outlook.com)